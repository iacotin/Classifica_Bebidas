fn_grava_dados <- function(tb_bebidas){
  source("./SCRIPTS/FUNCOES/FN_CONEXAO_SQLSERVER_S1670_2.R")
  con <- fn_s1670_NETSQL(con)

  ## SELECIONA COLUNAS
  tb_refrigerante$PROD_EMBALAGEM_SEFAZ <- tb_refrigerante$PROD_EMBALAGEM_AJUSTADO
  tb_refrigerante <- tb_refrigerante%>%
    select(IDNFE,DET_NITEM,PROD_XPROD,PROD_CPROD_SEFAZ_AJUSTADO
           ,PROD_XPROD_SEFAZ_AJUSTADO,PROD_CPROD_SEFAZ_DETALHADO,PROD_XPROD_SEFAZ_DETALHADO
           ,PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO,PROD_VOLUME_SEFAZ_AJUSTADO,PROD_EMBALAGEM_SEFAZ
           ,PROD_FATOR_MULTIPLICADOR,PROD_USEFAZ_AJUSTADO,PROD_QSEFAZ_AJUSTADO,PROD_VUNSEFAZ_AJUSTADO)
  #
  tb_cerveja$PROD_EMBALAGEM_SEFAZ <- tb_cerveja$PROD_EMBALAGEM_AJUSTADO
  tb_cerveja <- tb_cerveja%>%
    select(IDNFE,DET_NITEM,PROD_XPROD,PROD_CPROD_SEFAZ_AJUSTADO
           ,PROD_XPROD_SEFAZ_AJUSTADO,PROD_CPROD_SEFAZ_DETALHADO,PROD_XPROD_SEFAZ_DETALHADO
           ,PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO,PROD_VOLUME_SEFAZ_AJUSTADO,PROD_EMBALAGEM_SEFAZ
           ,PROD_FATOR_MULTIPLICADOR,PROD_USEFAZ_AJUSTADO,PROD_QSEFAZ_AJUSTADO,PROD_VUNSEFAZ_AJUSTADO)
  #
  df_nfe_diaria <- df_nfe_diaria%>%
    select(IDNFE,DET_NITEM,PROD_XPROD,PROD_CPROD_SEFAZ_AJUSTADO
           ,PROD_XPROD_SEFAZ_AJUSTADO,PROD_CPROD_SEFAZ_DETALHADO,PROD_XPROD_SEFAZ_DETALHADO
           ,PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO,PROD_VOLUME_SEFAZ_AJUSTADO,PROD_EMBALAGEM_SEFAZ
           ,PROD_FATOR_MULTIPLICADOR,PROD_USEFAZ_AJUSTADO,PROD_QSEFAZ_AJUSTADO,PROD_VUNSEFAZ_AJUSTADO)%>%
    mutate(PROD_CPROD_SEFAZ_DETALHADO = -1)%>%
    mutate(PROD_XPROD_SEFAZ_DETALHADO = "NULO")%>%
    mutate(PROD_VOLUME_SEFAZ_AJUSTADO = 0.00)%>%
    mutate(PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO = "NULO")%>%
    mutate(PROD_EMBALAGEM_SEFAZ = "NULO")%>%
    mutate(PROD_FATOR_MULTIPLICADOR = -1)%>%
    mutate(PROD_USEFAZ_AJUSTADO = "NULO")%>%
    mutate(PROD_QSEFAZ_AJUSTADO = 0.00)%>%
    mutate(PROD_VUNSEFAZ_AJUSTADO = 0.00)
  #
  tb_bebidas <- rbind(df_nfe_diaria,tb_refrigerante,tb_cerveja)
  colnames(tb_bebidas) <- tolower(colnames(tb_bebidas))
  ## GRAVA DADOS NO SQL
  #dbGetQuery(con,"DELETE FROM Nfe_Clf_Temp")
  #dbAppendTable(con,"Nfe_Clf_Temp",tb_bebidas)
  dbGetQuery(con,"DELETE FROM Nfe_Tmp_Classificada")
  dbAppendTable(con,"Nfe_Tmp_Classificada",tb_bebidas)
  
  ## GRAVA LOG EXECUCAO
  data_fim <- Sys.time()
  data_exec <- as.character(Sys.Date())
  tmp_total <- as.character(round(as.numeric(data_fim - data_ini),2))
  data_ini <- as.character(data_ini)
  data_fim <- as.character(data_fim)
  tb_registro <- data.frame(
    Data_Execucao = as.character(data_exec),
    Hora_Inicio = as.character(data_ini),
    Hora_Termino =as.character(data_fim),
    Duracao = tmp_total
  )
  
  tb_registro$Total_Registros <- nrow(tb_bebidas)
  source("./SCRIPTS/FUNCOES/FN_CONEXAO_SQLSERVER_S1670.R")
  con_ia <- fn_con_s1670(con_ia)
  dbAppendTable(con_ia,"TB_REGISTRO",tb_registro)
}