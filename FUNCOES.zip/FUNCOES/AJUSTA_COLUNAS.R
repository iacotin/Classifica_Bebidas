ajusta_colunas <- function(x,y,z,w){
  ###### AJUSTA COLUNAS PARA O PADRAO  "\\s\\d{1,2}x\\d{3,4}(\\s|$|m" (df_qte) ######
  x$QTE_TRIB_AJUSTADO <- str_extract(str_extract(tolower(x$PROD_XPROD),"\\s\\d{1,2}x"),"\\d{1,2}")
  x$FATOR_MULTIPLICADOR <- as.numeric(x$QTE_TRIB_AJUSTADO)
  x$QTE_SEFAZ <- x$FATOR_MULTIPLICADOR * x$PROD_QCOM
  x$VLR_UNITARIO_SEFAZ <- x$PROD_VPROD / x$QTE_SEFAZ

  ###### AJUSTA COLUNAS PARA O PADRAO "cx\\s?\\d{1,2}" (df_cx) ######
  
  
  ###### AJUSTA COLUNAS PARA O PADRAO "(pc(t)?\\d{2}$|\\d{1,2}\\s?u(n)?|c(x)?[[:punct:]]\\d{1,2})" (df_pdr) ######
  
  
  ###### AJUSTA COLUNAS PARA O PADRAO "\\d{1,2}\\s?x\\s?\\d{1,2}" (df_emb) ######
  return(x) 
}