limpa_xprod_2=function(x){
  x%>%
    stringr::str_to_lower() %>%
    stringr::str_replace_all("[/.,|()#%.:-]", " ") %>%
    stringr::str_replace_all("\\+{1,10}|\\*{1,10}","")%>%
    stringr::str_replace_all("\\d{1,30}","")%>%
    stringr::str_replace("\\s{1,10}","")
  
}