fn_cria_col_milho_soja <- function(x){
  ############# CRIA COLUNAS EXTRAS E DE APOIO#############
  x[,"FATOR_MULTIPLICADOR"] <- as.double()
  x[,"UNIDADE_SEFAZ"] <- "KG"
  x[,"VLR_UNITARIO_SEFAZ"] <- as.double()
  x[,"QTE_SEFAZ"] <- as.double()
  ########################################################
  return(x)
}