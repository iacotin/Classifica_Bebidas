fn_con_s904 <- function(x){
 con <- dbConnect(odbc::odbc(), .connection_string = "Driver={ODBC Driver 17 for SQL Server};SERVER=s904\\itc004;
 DATABASE=ugst_bebidas;
 UID=dbarantes;
 PWD=7s3Hb2eLsZFk6x2p;", timeout = 10) 
}