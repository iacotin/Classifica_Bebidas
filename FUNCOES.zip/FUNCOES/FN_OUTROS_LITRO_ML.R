fn_outros_padores_volume <- function(x){
  ### PADRAO LITRO ###
  id_litro <- grep("(\\s\\d\\slt)|(\\s\\dl)",x$PROD_XPROD,ignore.case = T)
  if(length(id_litro)>0){
    df_litro <- x[id_litro,]
    vol_litro = as.integer(str_extract(str_extract(tolower(df_litro$PROD_XPROD),"(\\s\\d\\slt)|(\\s\\dl)"),"\\d"))
    vol_litro <- vol_litro * 1000
    df_litro$VOLUME_SEFAZ <- vol_litro
    df_litro$UN_MEDIDA_SEFAZ <- "ML"
  }  
  
  ### PADRAO ML ###
  id_ml <- grep("\\s\\d,\\d{2,3}",x$PROD_XPROD,ignore.case = T)
  if(length(id_ml)>0){
    df_ml <- x[id_ml, ]
    vol_ml = str_extract(df_ml$PROD_XPROD,"\\s\\d,\\d{2,3}")
    vol_ml <- gsub(",",".",vol_ml)
    vol_ml <- as.double(vol_ml)*1000
    df_ml$VOLUME_SEFAZ <- vol_ml
    df_ml$UN_MEDIDA_SEFAZ <- "ML"
  }  
  ###
  df_litro_ml <- rbind(df_litro,df_ml)
  return(df_litro_ml)
}