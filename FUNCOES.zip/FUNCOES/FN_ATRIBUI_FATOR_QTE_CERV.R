fn_atribui_fator_qte <- function(x){
  x$FATOR_MULTIPLICADOR <- 6
  x$QTE_SEFAZ <- x$PROD_QCOM * x$FATOR_MULTIPLICADOR
  return(x)
}