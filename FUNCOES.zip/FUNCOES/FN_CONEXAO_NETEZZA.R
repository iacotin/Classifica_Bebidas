fn_conect_NZ <- function(x){
con <- dbConnect(
  RODBCDBI::ODBC(),
  dsn = "ODBC Driver for NetezzaSQL",
  "DRIVER=ODBC Driver for NetezzaSQL;SERVER=s1436.ms;DATABASE=TRIBUTARIO_REFERENCIA;ReadOnly=true;UID=esmaka;PWD=@q158850i4",
  case = 'nochange',
  believeNRows=FALSE
)}
