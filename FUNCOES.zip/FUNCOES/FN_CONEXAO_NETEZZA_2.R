fn_conect_NZ_2 <- function(x){
con <- dbConnect(
  RODBCDBI::ODBC(),
  dsn = "ODBC Driver for NetezzaSQL",
  "DRIVER=ODBC Driver for NetezzaSQL;SERVER=s1436.ms;DATABASE=MINING_SEFAZ;ReadOnly=false;UID=esmaka;PWD=@q158850i4",
  case = 'nochange',
  believeNRows=FALSE
)}
