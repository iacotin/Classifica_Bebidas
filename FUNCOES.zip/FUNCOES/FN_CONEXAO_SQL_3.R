fn_con_s1670_netSQL <- function(x){
 con <- dbConnect(odbc::odbc(), .connection_string = "Driver={ODBC Driver 17 for SQL Server};SERVER=s1670.ms\\itcsp01,1431;
 DATABASE=net_sql;
 UID=esmaka;
 PWD=11qw-SG9M;", timeout = 10)
}
