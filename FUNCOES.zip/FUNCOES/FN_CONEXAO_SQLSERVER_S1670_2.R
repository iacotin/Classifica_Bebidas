fn_s1670_NETSQL <- function(x){
 con <- dbConnect(odbc::odbc(), .connection_string = "Driver={ODBC Driver 17 for SQL Server};SERVER=s1670.ms\\itcsp01,1431;
 DATABASE=suporte_etl;
 UID=servico_hadoop;
 PWD=9u43l48hit9;", timeout = 10)
}
