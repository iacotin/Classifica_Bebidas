fn_out_vuntrib <- function(x){
  q1 = quantile(x$PROD_VUNTRIB,0.25)
  q3 = quantile(x$PROD_VUNTRIB,0.75)
  iq = q3 - q1
  lim_inf = q1-1.5*iq
  lim_sup = q3+1.5*iq
  x$OUT_VUNTRIB = (x$PROD_VUNTRIB > lim_sup | x$PROD_VUNTRIB < lim_inf)
  
  q1 = quantile(x$PROD_VUNCOM,0.25)
  q3 = quantile(x$PROD_VUNCOM,0.75)
  iq = q3 - q1
  lim_inf = q1-1.5*iq
  lim_sup = q3+1.5*iq
  x$OUT_VUNCOM = (x$PROD_VUNCOM > lim_sup | x$PROD_VUNCOM < lim_inf)
  return(x)
}
