fn_ler_dadosNF <- function(x){
  source("./SCRIPTS/FUNCOES/FN_CONEXAO_NETEZZA.R")
  NZ_TribRef <- fn_conect_NZ(NZ_TribRef)
  x <- dbGetQuery(NZ_TribRef,"SELECT T0.IDNFE,T0.DET_NITEM,T0.IDE_DHEMI_PERIODO,SQLKIT..regexp_replace(T0.PROD_XPROD,';','-') 
                              AS PROD_XPROD,T0.PROD_CPROD_SEFAZ_AJUSTADO, T0.PROD_UCOM,T0.PROD_QCOM,T0.PROD_VUNCOM,
                              T1.PROD_VPROD 
                              FROM TRIBUTARIO_REFERENCIA.ADMIN.TB_PRODUTO_SEFAZ_NFE T0
                              LEFT JOIN TRIBUTARIO_REFERENCIA.ADMIN.NFE T1 ON 
                              T0.IDNFE = T1.IDNFE AND T0.DET_NITEM = T1.DET_NITEM 
                              AND (T0.PROD_CPROD_SEFAZ_AJUSTADO = 10030440008 OR T0.PROD_CPROD_SEFAZ_AJUSTADO = 10030440006)    
                              AND T0.IDE_DHEMI_PERIODO BETWEEN 202001 AND 202002")
  rm(NZ_TribRef)
  return(x)
}
  