###############################################################################
##  PROJETO....: CALCULO PMPF REFRIGERANTES PELOS PRECOS NFCE                ##
##  SCRIPT.....: FORMULA CALCULO MEDIA ARITMETICA                            ##
##  DATA.......: 15 fevereiro 2021                                           ##
##  ANALISTA...: EMIR MANSUR SMAKA                                           ##
##  SETOR......: COTIN/UGDT                                                  ##
##  RESPONSAVEL: GERSON LUIZ DOS SANTOS                                      ##
###############################################################################

fn_pmpf_bebidas <- function(x){
  x$VLR_VENDA = x$PROD_VUNCOM * x$PROD_QCOM
  x$QTE_TOTAL = sum(x$PROD_QCOM)
  x$VLR_TOTAL = sum(x$VLR_VENDA)
  x$VLR_PMPF_CALCULADO_NFCE <- x$VLR_TOTAL/x$QTE_TOTAL
  return(x)
}