######## LIMPA XPROD  ######## 
library(stringr)
limpa_xprod = function(x){cerveja_treino <- x%>%
  select(PROD_XPROD,CPROD_CERVEJA_SEFAZ)

#cerveja_treino <- rename(cerveja_treino,CPROD_CERVEJA_SEFAZ = CPROD_CERVEJA_SEFAZ.y)

cerveja_treino$PROD_XPROD_LIMPO <- gsub("[[:digit:]]|[[:punct:]]"," ",cerveja_treino$PROD_XPROD)
cerveja_treino$PROD_XPROD_LIMPO <- str_trim(cerveja_treino$PROD_XPROD_LIMPO,side = "left")

remove_words <- c("cx|ml|cartao|six\\s?pack|cxa|\\ssh\\s|l?gfa|\\sl\\s|\\slt(\\s)?|vd|\\sx\\s|ln|\\s(c)\\s|npal|un(id)?|\\scom\\s|ttc|pct?|\\sc\\s")
remove_words2 <- c("lata(s|o)?|pack|alcool|\\sc\\s|sleek|\\scom\\s|\\sp\\s")
remove_words3 <- c("\\scom(\\s)?|\\sfi(\\s)?|\\sf\\s|pe\\sec\\srd|\\sprec\\s|\\sret\\s|\\spbr(\\s)?|\\su\\s|\\sgfs(\\s)?|^i\\s|\\sn$|\\sow|\\sd(\\s|$)|fora de linha|
                   garrfa|garrafa|long neck|caixa|cart\\s|\\spap|fridge")
cerveja_treino$PROD_XPROD_LIMPO2 <- gsub(remove_words,"",cerveja_treino$PROD_XPROD_LIMPO,ignore.case = T)
cerveja_treino$PROD_XPROD_LIMPO3 <- gsub(remove_words2,"",cerveja_treino$PROD_XPROD_LIMPO2,ignore.case = T)
cerveja_treino$PROD_XPROD_LIMPO <- NULL
cerveja_treino$PROD_XPROD_LIMPO2 <- NULL

cerveja_treino$PROD_XPROD_LIMPO4 <- gsub(remove_words3,"",cerveja_treino$PROD_XPROD_LIMPO3,ignore.case = T)
cerveja_treino$PROD_XPROD_LIMPO3 <- NULL
cerveja_treino <- rename(cerveja_treino,PROD_XPROD_LIMPO = PROD_XPROD_LIMPO4)

cerveja_treino$PROD_XPROD_LIMPO <- str_trim(cerveja_treino$PROD_XPROD_LIMPO,side = "left")
cerveja_treino$PROD_XPROD_LIMPO <- str_trim(cerveja_treino$PROD_XPROD_LIMPO,side = "right")

cerveja_treino$PROD_XPROD_LIMPO <- ifelse(cerveja_treino$PROD_XPROD_LIMPO == "","NULO",cerveja_treino$PROD_XPROD_LIMPO)
cerveja_treino$PROD_XPROD_LIMPO <- tolower(cerveja_treino$PROD_XPROD_LIMPO)

cerveja_treino$PROD_XPROD_LIMPO <- as.factor(cerveja_treino$PROD_XPROD_LIMPO)
cerveja_treino$CPROD_CERVEJA_SEFAZ <- as.factor(cerveja_treino$CPROD_CERVEJA_SEFAZ)
return(cerveja_treino)}
######## FIM LIMPA XPROD ######## 
