fn_separa_dados <- function(tb_tot,tb_refr,tb_cerv){
  ## SEPARA REFRI
  tb_refr <- tb_tot %>%
    filter(PROD_CPROD_SEFAZ_AJUSTADO == 10030440006)
  tb_refr$PROD_QCOM <- as.numeric(df_refrigerante$PROD_QCOM)
  tb_tot <- anti_join(tb_tot,tb_refr,by=c("IDNFE","DET_NITEM"))
  ## SEPARA CERVEJA
  tb_cerv <- tb_tot %>%
    filter(PROD_CPROD_SEFAZ_AJUSTADO == 10030440008)
  tb_cerv$PROD_QCOM <- as.numeric(df_cerveja$PROD_QCOM)
  tb_tot <- anti_join(tb_tot,tb_cerv,by=c("IDNFE","DET_NITEM"))
}


