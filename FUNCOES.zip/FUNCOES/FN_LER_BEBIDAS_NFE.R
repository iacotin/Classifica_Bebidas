fn_ler_bebidasNF <- function(x){
 ## CONECTA COM SERVER SQL S1617
 con <- dbConnect(odbc::odbc(), .connection_string = "Driver={ODBC Driver 17 for SQL Server};SERVER=s1670.ms\\itcsp01,1431;
 DATABASE=suporte_etl;
 UID=servico_hadoop;
 PWD=9u43l48hit9;", timeout = 10)
 #####################################
 
  x <- dbGetQuery(con,"SELECT T1.idnfe
       ,T1.det_nitem
       ,T1.prod_xprod
       ,T1.prod_cprod_sefaz_ajustado
       ,T1.prod_status_sefaz_ajustado
       ,T1.prod_xprod_sefaz_ajustado
       ,T1.prod_cprod_sefaz_detalhado
       ,T1.prod_xprod_sefaz_detalhado
       ,T1.prod_unidade_medida_sefaz_ajustado
       ,T1.prod_volume_sefaz_ajustado
       ,T1.prod_embalagem_sefaz
       ,T1.prod_fator_multiplicador
       ,T1.prod_usefaz_ajustado
       ,T1.prod_qsefaz_ajustado
       ,T1.prod_vunsefaz_ajustado
	   ,T2.prod_ucom
	   ,T2.prod_qcom
	   ,T2.prod_vuncom
	   ,T2.prod_vprod
  FROM [suporte_etl].[dbo].[Nfe_Tmp_Classificada] T1
  inner join [suporte_etl].[dbo].[Nfe_Tmp] T2 ON T1.idnfe = T2.idnfe AND T1.det_nitem = T2.det_nitem")
  #WHERE T1.prod_cprod_sefaz_ajustado IN (10030440006,10030440008)")
  return(x)
}
  