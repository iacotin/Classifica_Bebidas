fn_out_bebida <- function(x){
  q1 = quantile(x$PROD_VUNCOM,0.25)
  q3 = quantile(x$PROD_VUNCOM,0.75)
  iq = q3 - q1
  lim_inf = q1-1.5*iq
  lim_sup = q3+1.5*iq
  x$OUT = (x$PROD_VUNCOM > lim_sup | x$PROD_VUNCOM < lim_inf)
  return(x)
}
