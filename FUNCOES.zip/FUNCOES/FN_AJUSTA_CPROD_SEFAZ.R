### AJUSTA CPROD_SEFAZ_DETALHADO
fn_ajusta_cprod <- function(tb){
  cprod_2 <- substring(tb$PROD_CPROD_VAR, 6,7)
  
  tb <- tb%>%
    mutate(PROD_CPROD_VAR = paste("10030440006","000",cprod_2,sep = ""))
  
  return(tb)
}
