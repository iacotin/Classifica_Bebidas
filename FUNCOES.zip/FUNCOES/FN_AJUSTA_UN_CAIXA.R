fn_un_cx <- function(){
  id_cx <- grep("cx",df_refrigerante$PROD_UCOM,ignore.case = T)
  df_cx <- df_refrigerante[id_cx,]
  
  i_cx1 <- grep("\\s\\d\\d\\s",df_cx$PROD_XPROD,ignore.case = T)
  df_cx1 <- df_cx[i_cx1,]
  df_cx <- anti_join(df_cx,df_cx1,by=c("IDNFE","DET_NITEM"))
  
  i_cx2 <- grep("\\d{1,2}\\s?pack|\\d{1,2}\\s?p(\\s|$)",df_cx$PROD_XPROD,ignore.case = T)
  df_cx2 <- df_cx[i_cx2,]
  df_cx <- anti_join(df_cx,df_cx2,by=c("IDNFE","DET_NITEM"))
  
  i_cx3 <- grep("(\\d\\dx\\d)|\\dx\\d\\s?l",df_cx$PROD_XPROD,ignore.case = T)
  df_cx3 <- df_cx[i_cx3,]
  df_cx <- anti_join(df_cx,df_cx3,by=c("IDNFE","DET_NITEM"))
  
  i_cx4 <- grep("c\\/\\d\\d?|cx\\s?\\d\\d?",df_cx$PROD_XPROD,ignore.case = T)
  df_cx4 <- df_cx[i_cx4,]
  df_cx <- anti_join(df_cx,df_cx4,by=c("IDNFE","DET_NITEM"))
  
  df_cx1$FATOR_MULTIPLICADOR <- as.double(str_extract(df_cx1$PROD_XPROD,"\\s\\d\\d\\s"))
  df_cx1$QTE_SEFAZ <- df_cx1$FATOR_MULTIPLICADOR * df_cx1$PROD_QCOM
  
  df_cx2$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(tolower(df_cx2$PROD_XPROD),"\\d{1,2}\\s?pack|\\d{1,2}\\s?p(\\s|$)"),"\\d{1,2}"))
  df_cx2$QTE_SEFAZ <- df_cx2$FATOR_MULTIPLICADOR * df_cx2$PROD_QCOM
  
  df_cx3$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(str_extract(tolower(df_cx3$PROD_XPROD),"(\\d\\dx\\d)|\\dx\\d\\s?l"),"\\d{1,2}x"),"\\d{1,2}"))
  df_cx3$QTE_SEFAZ <- df_cx3$FATOR_MULTIPLICADOR * df_cx3$PROD_QCOM
  
  df_cx4$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(tolower(df_cx4$PROD_XPROD),"c\\/\\d\\d?|cx\\s?\\d\\d?"),"\\d{1,2}"))
  df_cx4$QTE_SEFAZ <- df_cx4$FATOR_MULTIPLICADOR * df_cx4$PROD_QCOM
  
  tb_cx <- rbind(df_cx1,df_cx2,df_cx3,df_cx4)
  return(tb_cx)
}