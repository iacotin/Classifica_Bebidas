fn_ler_bebidasNF <- function(x){
  ## CONECTA COM SERVER SQL S1617
  con <- dbConnect(odbc::odbc(), .connection_string = "Driver={ODBC Driver 17 for SQL Server};SERVER=s1670.ms\\itcsp01,1431;
 DATABASE=suporte_ia;
 UID=servico_hadoop;
 PWD=9u43l48hit9;", timeout = 10)
  #####################################
  
  x <- dbGetQuery(con,"SELECT [IDNFE]
      ,[DET_NITEM]
      ,[IDE_DHEMI_PERIODO]
      ,[PROD_XPROD]
      ,[PROD_CPROD_SEFAZ_AJUSTADO]
      ,[PROD_STATUS_SEFAZ_AJUSTADO]
      ,[PROD_XPROD_SEFAZ_AJUSTADO]
      ,[PROD_CPROD_SEFAZ_DETALHADO]
      ,[PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO]
      ,[PROD_VOLUME_SEFAZ_AJUSTADO]
      ,[PROD_EMBALAGEM_AJUSTADO]
      ,[PROD_FATOR_MULTIPLICADOR]
      ,[PROD_USEFAZ_AJUSTADO]
      ,[PROD_QSEFAZ_AJUSTADO]
      ,[PROD_VUNSEFAZ_AJUSTADO]
      ,[PROD_UCOM]
      ,[PROD_VUNCOM]
      ,[PROD_QCOM]
      ,[PROD_VPROD]
  FROM [suporte_ia].[dbo].[TB_BEBIDAS_2020a2022]
  WHERE IDE_DHEMI_PERIODO BETWEEN 202001 AND 202012")
  return(x)
}