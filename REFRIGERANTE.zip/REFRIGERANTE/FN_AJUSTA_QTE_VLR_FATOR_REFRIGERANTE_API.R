###############################################################################
##  SCRIPT.....: AJUSTES PARA REFRIGERANTES                                  ##
##  DETALHE....: AJUSTA VALOR UNITARIO, QUANTIDADE E FATOR MULTIPLICADOR     ##
##  DATA.......: 15 setembro 2020                                            ##
##  PROJETO....: CLASSIFICACAO DE PRODUTOS SEFAZ                             ##
##  ANALISTA...: EMIR MANSUR SMAKA                                           ##
##  SETOR......: COTIN/UGDT                                                  ##
##  RESPONSAVEL: GERSON LUIZ DOS SANTOS                                      ##
###############################################################################

fn_ajustes_refri <- function(df_refrigerante){
  
  ########################################
  df_class <- df_refrigerante[FALSE, ]
  ######################################## PADROES DE QTDE EM PROD_QCOM ########################################################
  ### PADRAO DUZIAS EM PROD_UCOM == "DZ/DU"
  id_dz <- grep("^dz|^du",df_refrigerante$PROD_UCOM,ignore.case = T)
  if(length(id_dz)>0){
    df_dz <- df_refrigerante[id_dz,]
    df_refrigerante <- anti_join(df_refrigerante,df_dz,by=c("IDNFE","DET_NITEM"))
    df_dz$FATOR_MULTIPLICADOR <- 12
    df_dz$QTE_SEFAZ <- df_dz$FATOR_MULTIPLICADOR * df_dz$PROD_QCOM
    df_class <- rbind(df_class,df_dz)
    rm(id_dz)
  }
  
  ### Seleciona Padrao PROD_UCOM descrito como "cxdd" onde dd representa o  numero de unidades na embalagem
  id_cx<-grep("c[x]\\s?\\d{1,4}",df_refrigerante$PROD_UCOM, ignore.case = T)
  if(length(id_cx)>0){
    df_cx <- df_refrigerante[id_cx,]
    df_refrigerante <- anti_join(df_refrigerante,df_cx,by=c("IDNFE","DET_NITEM"))
    df_cx$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(tolower(df_cx$PROD_UCOM),"c[x]\\s?\\d{1,4}$"),"[0-9]{1,4}"))
    df_cx$QTE_SEFAZ<- df_cx$FATOR_MULTIPLICADOR * df_cx$PROD_QCOM
    df_class <- rbind(df_class,df_cx)
    rm(id_cx)
  }
  
  ### PADRAO PROD_QCOM DECLARADO COMO 'UNdd' ONDE dd REPRESENTA A QTDE DE UNIDADES
  id_undd <- grep("un\\d{1,4}",df_refrigerante$PROD_UCOM,ignore.case = T)
  if(length(id_undd)>0){
    df_undd <- df_refrigerante[id_undd,]
    df_refrigerante <- anti_join(df_refrigerante,df_undd,by=c("IDNFE","DET_NITEM"))
    df_undd$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(tolower(df_undd$PROD_UCOM),"un\\d{1,4}"),"\\d{1,4}"))
    df_undd$QTE_SEFAZ <- df_undd$FATOR_MULTIPLICADOR * df_undd$PROD_QCOM
    df_class <- rbind(df_class,df_undd)
    rm(id_undd)
  }
  
  ### PADRAO PROD_QCOM DECLARADO COMO 'UN..' ASSUME QUE A QUANTIDADE ESTEJA DECLARADA EM UNIDADES
  id_un <-  grep("^u",df_refrigerante$PROD_UCOM,ignore.case = T)
  if(length(id_un)>0){
    df_un <- df_refrigerante[id_un,]
    df_refrigerante <- anti_join(df_refrigerante,df_un,by=c("IDNFE","DET_NITEM"))
    df_un$FATOR_MULTIPLICADOR <- 1
    df_un$QTE_SEFAZ <- df_un$FATOR_MULTIPLICADOR * df_un$PROD_QCOM
    df_class <- rbind(df_class,df_un)
    rm(id_un)
  }
  
  ### PADRAO DE REGISTROS 'SX' EM PROD_QCOM ==> SiX 6 UNIDADES
  id_sx <- grep("sx",df_refrigerante$PROD_UCOM,ignore.case = T)
  if(length(id_sx)>0){
    df_sx <- df_refrigerante[id_sx,]
    df_refrigerante <- anti_join(df_refrigerante,df_sx,by=c("IDNFE","DET_NITEM"))
    df_sx$FATOR_MULTIPLICADOR <- 6
    df_sx$QTE_SEFAZ <- df_sx$FATOR_MULTIPLICADOR * df_sx$PROD_QCOM
    df_class <- rbind(df_class,df_sx)
    rm(id_sx)
  }
  
  ###################################################################
  rm(df_dz,df_cx,df_sx,df_un,df_undd)
  ###################################################################
  
  #############################################################################################################################
  
  ######################################## PADROES DE QTDE EM PROD_XPROD ######################################################
  id_un <- grep("\\s\\d{1,3}\\s?u",df_refrigerante$PROD_XPROD,ignore.case = T)
  if(length(id_un)>0){
    df_un <- df_refrigerante[id_un,]
    df_refrigerante <- anti_join(df_refrigerante,df_un,by=c("IDNFE","DET_NITEM"))
    df_un$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(tolower(df_un$PROD_XPROD),"\\s\\d{1,3}\\s?u"),"\\d{1,3}"))
    df_un$QTE_SEFAZ <- df_un$FATOR_MULTIPLICADOR * df_un$PROD_QCOM
    df_class <- rbind(df_class,df_un)
    rm(id_un)
  }
  
  #### REGEX PARA IDENTIFICAR PADRAO 999 X 999 EM XPROD
  id_qte <- grep("[1-9]{1,2}(\\s)?x(\\s)?\\d\\d\\d",df_refrigerante$PROD_XPROD,ignore.case = T) # cria indice dos padroes no data frame
  if(length(id_qte)>0){
    df_refri_qte <- df_refrigerante[id_qte,]
    df_refrigerante <- anti_join(df_refrigerante,df_refri_qte,by=c("IDNFE","DET_NITEM"))
    df_refri_qte$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(tolower(df_refri_qte$PROD_XPROD),"[0-9]{1,3}(\\s)?x(\\s)?\\d\\d\\d"),"\\d{1,3}"))
    df_refri_qte$QTE_SEFAZ <- df_refri_qte$FATOR_MULTIPLICADOR * df_refri_qte$PROD_QCOM
    df_class <- rbind(df_class,df_refri_qte)
    rm(id_qte)
  }
  ###################################################
  
  ###
  id_m2 <- grep("\\sx\\s(\\d\\d)\\d?\\s",df_refrigerante$PROD_XPROD,ignore.case = T)
  if(length(id_m2)>0){
    df_refri_m2 <- df_refrigerante[id_m2,]
    df_refrigerante <- anti_join(df_refrigerante,df_refri_m2,by=c("IDNFE","DET_NITEM"))
    df_refri_m2$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(tolower(df_refri_m2$PROD_XPROD),"\\sx\\s(\\d\\d)\\d?\\s"),"[0-9]{2}"))
    df_refri_m2$QTE_SEFAZ <- df_refri_m2$FATOR_MULTIPLICADOR  * df_refri_m2$PROD_QCOM
    df_class <- rbind(df_class,df_refri_m2)
    rm(id_m2)
  }
  ###################################################
  
  id_m3 <- grep("\\sc[x]?(.)?\\d{1,4}",df_refrigerante$PROD_XPROD,ignore.case = T)
  if(length(id_m3)>0){
    df_refri_m3 <- df_refrigerante[id_m3,]
    df_refrigerante <- anti_join(df_refrigerante,df_refri_m3,by=c("IDNFE","DET_NITEM"))
    df_refri_m3$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(tolower(df_refri_m3$PROD_XPROD),"\\sc[x]?(.)?\\d{1,4}"),"[0-9]{1,4}"))
    df_refri_m3$QTE_SEFAZ <-  df_refri_m3$FATOR_MULTIPLICADOR * df_refri_m3$PROD_QCOM
    df_class <- rbind(df_class,df_refri_m3)
    rm(id_m3)
  }
  ###
  
  #### APAGA DF TEMPORARIOS ####
  rm(df_refri_qte,df_refri_m3,df_un)
  #####################################################
  
  ### Ajusta QTE_TRIB para outros padroes identificados (PCT ou PC)
  id_m4 <- grep("(pc|pct|pctc)(\\s)?([0-9]){1,3}",df_refrigerante$PROD_XPROD,ignore.case = T)
  if(length(id_m4)>0){
    df_m4 <- df_refrigerante[id_m4,]
    df_refrigerante <- anti_join(df_refrigerante,df_m4,by=c("IDNFE","DET_NITEM"))
    df_m4$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(tolower(df_m4$PROD_XPROD),"(pc|pct)(\\s)?([0-9]){1,3}"),"[0-9]{1,3}"))
    df_m4$QTE_SEFAZ <- df_m4$FATOR_MULTIPLICADOR * df_m4$PROD_QCOM
    df_class <- rbind(df_class,df_m4)
    rm(id_m4,df_m4)
  }
  ####################################################
  
  ##### PADROES EM PROD_XPROD PARA PROD_UCOM == "CX"
  tb_cx <- fn_un_cx(df_refrigerante,tb_cx)
  df_refrigerante <- anti_join(df_refrigerante,tb_cx,by=c("IDNFE","DET_NITEM"))
  df_class <- rbind(df_class,tb_cx)
  gc(reset = T)
  ######################################################################
  
  ### PADRAO COM QTEXVOLUME
  id_qte <- grep("\\s\\d\\d?x\\d(\\s|$)",df_refrigerante$PROD_XPROD,ignore.case = T)
  if(length(id_qte)>0){
    df_qte <- df_refrigerante[id_qte,]
    df_refrigerante <- anti_join(df_refrigerante,df_qte,by=c("IDNFE","DET_NITEM"))
    df_qte$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(tolower(df_qte$PROD_XPROD),"\\s\\d\\d?x\\d(\\s|$)"),"\\d{1,2}"))
    df_qte$QTE_SEFAZ <- df_qte$FATOR_MULTIPLICADOR * df_qte$PROD_QCOM
    df_class <- rbind(df_class,df_qte)
    rm(id_qte)
  }
  ######################################################################################
  
  ### PADROES DIVERSOS ENCONTRADOS EM PROD_XPROD
  id_dv1 <- grep("lt\\s?\\d{1,2}(\\s|x)",df_refrigerante$PROD_XPROD, ignore.case = T)
  if(length(id_dv1)>0){
    df_dv1 <- df_refrigerante[id_dv1,]
    df_refrigerante <- anti_join(df_refrigerante,df_dv1,by=c("IDNFE","DET_NITEM"))
    df_dv1$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(tolower(df_dv1$PROD_XPROD),"lt\\s?\\d{1,2}(\\s|x)"),"\\d{1,2}"))
    df_dv1$QTE_SEFAZ <- df_dv1$FATOR_MULTIPLICADOR * df_dv1$PROD_QCOM
    df_class <- rbind(df_class,df_dv1)
  }
  
  id_dv2 <- grep("\\d{1,2}\\s?x\\s?\\d{1,2}",df_refrigerante$PROD_XPROD,ignore.case = T)
  if(length(id_dv2)>0){
    df_dv2 <- df_refrigerante[id_dv2,]
    df_refrigerante <- anti_join(df_refrigerante,df_dv2,by=c("IDNFE","DET_NITEM"))
    p1 <- as.double(str_extract(str_extract(tolower(df_dv2$PROD_XPROD),"\\d{1,2}\\s?x"),"\\d{1,2}"))
    p2 <- as.double(str_extract(str_extract(tolower(df_dv2$PROD_XPROD),"x\\s?\\d{1,2}"),"\\d{1,2}"))
    df_dv2$FATOR_MULTIPLICADOR <- ifelse(p1>=p2,p1,p2)
    df_dv2$QTE_SEFAZ <- df_dv2$FATOR_MULTIPLICADOR * df_dv2$PROD_QCOM
    df_class <- rbind(df_class,df_dv2)
  }
  
  ## UNIR DATAFRAMES AJUSTADOS
  rm(df_qte,df_dv1,df_dv2,id_dv1,id_dv2,p1,p2)
  ######################################################################################
  
  #### PADROES NUMERICOS INDICANDO EMBALAGENS COM 6,12 E 24 UNIDADES
  id_emb <- grep("\\<6\\>|\\<06\\>|\\<12\\>|\\<24\\>|\\<lt12\\>|\\<lt6\\>",df_refrigerante$PROD_XPROD,ignore.case = T)
  df_emb <- df_refrigerante[id_emb,]
  df_refrigerante <- anti_join(df_refrigerante,df_emb,by=c("IDNFE","DET_NITEM"))
  
  df_emb$FATOR_MULTIPLICADOR <- as.double(str_extract(str_extract(tolower(df_emb$PROD_XPROD),"6|06|12|24|lt12|lt6"),"\\d{1,2}"))
  df_emb$QTE_SEFAZ <- df_emb$FATOR_MULTIPLICADOR * df_emb$PROD_QCOM
  #
  df_class <- rbind(df_class,df_emb)
  
  rm(df_emb,id_emb)
  gc(reset = T)
  ######################################################################################
  
  #### PADRAO FDXX INDICADO EM PROD_UCOM
  id_fd <- grep("fd\\d{1,2}",df_refrigerante$PROD_UCOM,ignore.case = T)
  if(length(id_fd)>0){
    df_fd <- df_refrigerante[id_fd,]
    df_refrigerante <- anti_join(df_refrigerante,df_fd,by=c("IDNFE","DET_NITEM"))
    df_fd$FATOR_MULTIPLICADOR <- as.double(str_extract(df_fd$PROD_UCOM,"\\d{1,2}"))
    df_fd$QTE_SEFAZ <- df_fd$FATOR_MULTIPLICADOR * df_fd$PROD_QCOM
    df_class <- rbind(df_class,df_fd)
  }
  
  df_class$VLR_UNITARIO_SEFAZ <- df_class$PROD_VPROD / df_class$QTE_SEFAZ
  rm(df_fd,id_fd)
  ######################################################################################
  
  ##df_refrigerante <- rbind(df_refrigerante,df_nao_refri)
  df_refrigerante$FATOR_MULTIPLICADOR <- -1
  df_refrigerante$QTE_SEFAZ <- -1
  
  #### UNIFICA AS TABELAS
  df_refrigerante <- rbind(df_class,df_refrigerante)
  rm(df_class)
  gc(reset = T)
  ######################################################### FIM PADROES QUANTIDADE #########################################################
  return(df_refrigerante)
}

######################################################### FIM PADROES QUANTIDADE #########################################################


