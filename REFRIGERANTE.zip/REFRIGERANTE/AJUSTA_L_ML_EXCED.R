df_litro <- refri_sem_ajuste[id_litro,]
refri_sem_ajuste <- anti_join(refri_sem_ajuste,df_litro,by=c("IDNFE","DET_NITEM"))
df_litro$VOLUME_SEFAZ <- as.double(str_extract(str_extract(tolower(df_litro$PROD_XPROD),"\\dl"),"\\d"))
nlinha <- nrow(df_litro)
df_litro$UN_MEDIDA_SEFAZ <- ifelse(nlinha > 0,"L",df_litro$UN_MEDIDA_SEFAZ)

df_refri_ajustado <- rbind(df_refri_ajustado,df_litro)
rm(df_litro,id_litro,df_i)