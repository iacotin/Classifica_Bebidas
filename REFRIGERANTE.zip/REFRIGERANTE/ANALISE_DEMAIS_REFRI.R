###### ANALISE REGISTROS IDENTIFICADOS COMO "DEMAIS REFRIGERANTES"
######

## SEPARA REGISTROS CLASSIFICADOS COMO DEMAIS REFRIGERANTES
tb_outros_refri <- df_refri_NFE_NFCE%>%
  filter(PROD_XPROD_SEFAZ == 'DEMAIS REFRIGERANTES' & VOLUME_SEFAZ != -1)%>%
  group_by(PROD_XPROD, PROD_XPROD_SEFAZ,CEANTRIB_NFCE,VOLUME_SEFAZ)%>%
  summarise(TOTAL = n())%>%
  arrange(desc(TOTAL))

##
tb_outros_refri_pmpf <- inner_join(tb_outros_refri,df_pmpf, by="CEANTRIB_NFCE")
tb_outros_refri <- anti_join(tb_outros_refri,tb_outros_refri_pmpf,by="CEANTRIB_NFCE")
