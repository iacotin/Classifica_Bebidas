## CARREGA BIBLIOTECAS
library(dplyr)
library(openxlsx)
library(data.table)
library(h2o)
library(bit64)
library(RODBC)
library(DBI)

setwd("/home/local/FAZENDA/PROJETOS/CLASS_PROD")
source("./SCRIPTS/FUNCOES/FN_CONEXAO_NETEZZA.R")
source("./SCRIPTS/FUNCOES/FN_LIMPA_XPROD.R")
nzodbc <- fn_conect_NZ(nzodbc)

df_refri <- dbGetQuery(nzodbc,"SELECT SQLKIT..regexp_replace(PROD_XPROD, ';','-') AS PROD_XPROD         
FROM TRIBUTARIO_REFERENCIA.ADMIN.TB_PRODUTO_SEFAZ_NFE
WHERE PROD_CPROD_SEFAZ_AJUSTADO = 10030440006
AND IDE_DHEMI_PERIODO BETWEEN 201901 AND 201906")


## PREPARA CONJUNTO DE DADOS PARA TREINAMENTO
tb_rotulado <- read.xlsx("./DADOS/REFRIGERANTE_ROTULADO.xlsx",sheet = "REFRIGERANTE_ROTULADO")
tb_rotulado$PROD_XPROD <- as.factor(tb_rotulado$PROD_XPROD)
tb_rotulado$TOTAL <- ifelse(is.na(tb_rotulado$TOTAL),130,tb_rotulado$TOTAL)
tb_rotulado <- distinct(tb_rotulado,PROD_XPROD,CPROD_REFRIGERANTE_SEFAZ,TOTAL)

refri_treino <- full_join(df_refri,tb_rotulado, by = "PROD_XPROD")


## LIMPRA XPROD
#refri_treino <- fn_limpa_xprod(refri_treino)
refri_treino$CPROD_REFRIGERANTE_SEFAZ <- as.factor(refri_treino$CPROD_REFRIGERANTE_SEFAZ)
refri_treino$PROD_XPROD <- as.factor(refri_treino$PROD_XPROD)

refri_treino <- refri_treino%>%
  filter(CPROD_REFRIGERANTE_SEFAZ != is.na(CPROD_REFRIGERANTE_SEFAZ))

rm(tb_rotulado,df_refri)
gc(reset = TRUE)


######## PREPARA A SAMPLE_RATE_PER_CLASS ########
tb_rate <- refri_treino%>%
  group_by(CPROD_REFRIGERANTE_SEFAZ)%>%
  dplyr::summarise(TOTAL = n())%>%
  arrange(CPROD_REFRIGERANTE_SEFAZ)
tb_rate <- as.data.frame(tb_rate)

tb_rate$RATE <- ifelse(tb_rate$TOTAL < 50000,1,0.6)
list_rate <- c(tb_rate$RATE)
######## FIM PREPARA A SAMPLE_RATE_PER_CLASS ######## 

## INICIA h2o
h2o.init(nthreads = -1, max_mem_size = "30G")
h2o.removeAll()

refri_treino.hex <- as.h2o(refri_treino)
refri_treino.hex$CPROD_REFRIGERANTE_SEFAZ <- as.factor(refri_treino.hex$CPROD_REFRIGERANTE_SEFAZ)
refri_treino.hex$PROD_XPROD_LIMPO <- as.factor(refri_treino.hex$PROD_XPROD)
refri_split = h2o.splitFrame(data = refri_treino.hex,
                             ratios = c(0.7),
                             destination_frames = c("refri.train.hex",
                                                    "refri.valida.hex"),
                             seed = 12345)

refri.train = refri_split[[1]]
refri.valida = refri_split[[2]]


## TREINA E VALIDA MODELO
gbm_4 <- h2o.gbm(model_id = "GBM_REFRI_NFE_V2",
                 x = "PROD_XPROD", 
                 y = "CPROD_REFRIGERANTE_SEFAZ",
                 distribution = "multinomial",
                 ntrees = 600,
                 max_depth = 6,
                 nfolds = 6,
                 seed = 1111,
                 sample_rate_per_class = list_rate,
                 training_frame = refri.train,
                 validation_frame = refri.valida)

## ANALISE DE DESEMPENHO

matriz_conf_refri <- h2o.confusionMatrix(gbm_4, valid = TRUE)

h2o.save_mojo(gbm_4,path = "./MODELOS/",force = TRUE)

h2o.shutdown(prompt = FALSE)

rm(list = ls())



