###############
#### AJUSTA VLR_UNITARIO_SEFAZ E QTE_SEFAZ NAO AJUSTADOS 
df_refrig <- df_refrigerante%>%
  filter(is.na(VLR_UNITARIO_SEFAZ) & FATOR_MULTIPLICADOR > 0 & PROD_QCOM > 0)%>%
  mutate(QTE_SEFAZ = PROD_QCOM * FATOR_MULTIPLICADOR)%>%
  mutate(VLR_UNITARIO_SEFAZ = PROD_VPROD / QTE_SEFAZ)

df_refrigerante <- anti_join(df_refrigerante,df_refrig,by=c("IDNFE","DET_NITEM"))
df_refrigerante <- rbind(df_refrigerante,df_refrig)
rm(df_refrig)
gc(reset = T)

######################################################################################

#### RENOMEAR COLUNAS PARA PADRAO SEFAZ
df_refrigerante <- fn_ajusta_nomes_col(df_refrigerante)
######################################################################################

#### CONVERTER UNIDADE MEDIDA DE L PARA ML BEM COMO O VOLUME
df_refrigerante$PROD_VOLUME_SEFAZ_AJUSTADO <-  ifelse(df_refrigerante$PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO == 'L'
                                                      ,df_refrigerante$PROD_VOLUME_SEFAZ_AJUSTADO * 1000
                                                      ,df_refrigerante$PROD_VOLUME_SEFAZ_AJUSTADO)

df_refrigerante$PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO <-  ifelse(df_refrigerante$PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO == 'L'
                                                              ,'ML',df_refrigerante$PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO)
######################################################################################

#### IDENTIFICA TIPO DE EMBALAGEM
i_embalagem <-  grep("\\<pet\\>",df_refrigerante$PROD_XPROD,ignore.case = T)
df_refri_pet <- df_refrigerante[i_embalagem,]
df_refrigerante <- anti_join(df_refrigerante,df_refri_pet,by=c("IDNFE","DET_NITEM"))

df_refri_ml <- df_refrigerante%>%
filter(PROD_VOLUME_SEFAZ_AJUSTADO < 1000)
df_refrigerante <- anti_join(df_refrigerante,df_refri_ml,by=c("IDNFE","DET_NITEM"))

i_ks <- grep("\\<ks\\>",df_refri_ml$PROD_XPROD,ignore.case = T)
df_refri_ks <- df_refri_ml[i_ks,]
df_refri_ml <- anti_join(df_refri_ml,df_refri_ks,by=c("IDNFE","DET_NITEM"))

i_lata <- grep("\\<lt\\>|\\<lata\\>|\\<lta\\>",df_refri_ml$PROD_XPROD,ignore.case = T)
df_refri_lata <- df_refri_ml[i_lata,]
df_refri_ml <- anti_join(df_refri_ml,df_refri_lata,by=c("IDNFE","DET_NITEM"))

df_refri_ks$PROD_EMBALAGEM_AJUSTADO <- "GARRAFA"
df_refri_lata$PROD_EMBALAGEM_AJUSTADO <- "LATA"
df_refri_pet$PROD_EMBALAGEM_AJUSTADO <- "PET"
df_refri_ml$PROD_EMBALAGEM_AJUSTADO <- "SEM AJUSTE"
df_refrigerante$PROD_EMBALAGEM_AJUSTADO <- "SEM AJUSTE"

df_refrigerante <- rbind(df_refri_ks,df_refri_lata,df_refri_ml,df_refri_pet,df_refrigerante)
rm(df_refri_ks,df_refri_lata,df_refri_ml,df_refri_pet,i_ks,i_lata,i_embalagem)
gc(reset = T)

########## AJUSTA VALORES NULOS ###############
#df_refrigerante$PROD_VUNSEFAZ_AJUSTADO <- ifelse(is.na(df_refrigerante$PROD_VUNSEFAZ_AJUSTADO),
#                                                 -1,df_refrigerante$PROD_VUNSEFAZ_AJUSTADO)

df_refrigerante$PROD_FATOR_MULTIPLICADOR <- ifelse(is.na(df_refrigerante$PROD_FATOR_MULTIPLICADOR)
                                                   ,-1,df_refrigerante$PROD_FATOR_MULTIPLICADOR)

df_refrigerante$PROD_VOLUME_SEFAZ_AJUSTADO <- ifelse(is.na(df_refrigerante$PROD_VOLUME_SEFAZ_AJUSTADO)
                                                     ,-1,df_refrigerante$PROD_VOLUME_SEFAZ_AJUSTADO)

df_refrigerante$PROD_QSEFAZ_AJUSTADO <- ifelse(is.na(df_refrigerante$PROD_QSEFAZ_AJUSTADO)
                                               ,-1,df_refrigerante$PROD_QSEFAZ_AJUSTADO)

df_refrigerante$PROD_VUNSEFAZ_AJUSTADO <- ifelse(is.na(df_refrigerante$PROD_VUNSEFAZ_AJUSTADO)
                                                 ,0.00,df_refrigerante$PROD_VUNSEFAZ_AJUSTADO)

df_refrigerante$PROD_VUNSEFAZ_AJUSTADO <- ifelse(df_refrigerante$PROD_VUNSEFAZ_AJUSTADO == "Inf"
       ,0.00,df_refrigerante$PROD_VUNSEFAZ_AJUSTADO)

df_refrigerante$PROD_VUNSEFAZ_AJUSTADO <- ifelse(df_refrigerante$PROD_VUNSEFAZ_AJUSTADO == -1
                                                 ,0.00,df_refrigerante$PROD_VUNSEFAZ_AJUSTADO)
df_refrigerante$PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO <- ifelse(is.na(df_refrigerante$PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO)
                                                             ,"NULO",df_refrigerante$PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO)

tb_refrigerante <- df_refrigerante%>%
  select(IDNFE,DET_NITEM,PROD_XPROD,PROD_CPROD_SEFAZ_AJUSTADO
         ,PROD_XPROD_SEFAZ_AJUSTADO,PROD_CPROD_SEFAZ_DETALHADO,PROD_XPROD_SEFAZ_DETALHADO
         ,PROD_UNIDADE_MEDIDA_SEFAZ_AJUSTADO,PROD_VOLUME_SEFAZ_AJUSTADO,PROD_EMBALAGEM_AJUSTADO
         ,PROD_FATOR_MULTIPLICADOR,PROD_USEFAZ_AJUSTADO,PROD_QSEFAZ_AJUSTADO,PROD_VUNSEFAZ_AJUSTADO)

## AJUSTA CODIGO SEFAZ DO PRODUTO DETALHADO
tb_999 <- tb_refrigerante%>%
  filter(PROD_CPROD_SEFAZ_DETALHADO == -9999999)

tb_refrigerante <- anti_join(tb_refrigerante,tb_999,by=c("IDNFE","DET_NITEM"))

tb_refrigerante$PROD_CPROD_VAR <- as.character(paste("10030440006","000",
                                                     substring(tb_refrigerante$PROD_CPROD_SEFAZ_DETALHADO,6,7),sep = ""))

tb_refrigerante$PROD_CPROD_SEFAZ_DETALHADO <- tb_refrigerante$PROD_CPROD_VAR
tb_refrigerante$PROD_CPROD_VAR <- NULL
tb_999$PROD_CPROD_VAR <- "-9999999999999999"
tb_999$PROD_CPROD_SEFAZ_DETALHADO <- tb_999$PROD_CPROD_VAR
tb_999$PROD_CPROD_VAR <- NULL

tb_refrigerante <- rbind(tb_refrigerante,tb_999)
rm(tb_999)
############################################################

fwrite(tb_refrigerante,"./DADOS/TB_REFRIGERANTE.csv",sep = ";")

######################## FIM AJUSTES FINAIS REFRIGERANTES ######################## 

